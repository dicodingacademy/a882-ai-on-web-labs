import {
	getCameraConfig,
	getCameraConstraints,
	getCameraErrorMessage,
	logError
} from '../core/utils.js';

class CameraService {
	constructor() {
		this.stream = null;
		this.video = null;
		this.canvas = null;
		this.config = getCameraConfig();

		this.initializeElements();
		this.init();
	}

	// TODO [Basic] Implementasikan metode untuk menginisialisasi elemen DOM yang diperlukan
	initializeElements() {}

	async init() {
		await this.loadCameras();
	}

	// TODO [Basic] Implementasikan metode untuk memuat daftar kamera yang tersedia
	async loadCameras() {
		try { } catch (error) {
			logError('Gagal memuat kamera', error);
			throw new Error(`Akses kamera gagal: ${error.message}`);
		}
	}

	// TODO [Basic] Implementasikan metode untuk memulai kamera dengan constraints yang sesuai
	async startCamera() {
		try { } catch (error) {
			logError('Gagal memulai kamera', error);
			const errorMessage = getCameraErrorMessage(error);
			throw new Error(errorMessage);
		}
	}

	// TODO [Basic] Implementasikan metode untuk menghentikan kamera
	stopCamera() {}

	// TODO [Skilled] Implementasikan metode untuk mengatur FPS kamera
	setFPS(fps) {}

	isActive() {
		return this.stream && this.stream.active;
	}

	isReady() {
		return this.isActive() &&
			this.video &&
			this.video.readyState >= 2 &&
			!this.video.paused;
	}

	captureFrame() {
		if (!this.isReady() || !this.canvas) {
			return null;
		}

		const ctx = this.canvas.getContext('2d');
		this.canvas.width = this.video.videoWidth;
		this.canvas.height = this.video.videoHeight;
		ctx.drawImage(this.video, 0, 0);

		return this.canvas;
	}
}

export default CameraService;
