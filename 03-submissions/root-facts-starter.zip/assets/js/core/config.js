export const APP_CONFIG = {
  detectionConfidenceThreshold: 70,
  analyzingDelay: 2000,
  funFactGenerationDelay: 2000,
  detectionRetryInterval: 100
};

export const TENSORFLOW_CONFIG = {
  modelPath: './model/model.json',
  metadataPath: './model/metadata.json',
  inputSize: [224, 224],
  normalizationFactor: 255.0,
  confidenceThreshold: 0.9,
};

export const TRANSFORMERS_CONFIG = {
  modelName: 'Xenova/LaMini-Flan-T5-77M',
  cdnUrl: 'https://cdn.jsdelivr.net/npm/@xenova/transformers@2.17.2',
  maxTokens: 80,
  temperature: 0.1,
  topP: 0.8,
  generationDelay: 500,
};

export const UI_CONFIG = {
  fadeAnimation: 'fadeIn 0.5s ease-out forwards',
  confidenceThresholds: {
    excellent: 90,
    good: 80
  }
};

export const CAMERA_CONFIG = {
  defaultFPS: 30,
  fpsRange: { min: 15, max: 60 },
  desktopResolution: { width: 640, height: 480 },
  mobileResolution: { width: 480, height: 640 },
  desktopFacingMode: 'user',
  mobileFacingMode: 'environment'
};
