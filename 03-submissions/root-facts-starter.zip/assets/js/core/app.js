import UIHandler from '../ui/ui.handler.js';
import {
	APP_CONFIG,
	logError
} from './utils.js';

class RootFactsApp {
	constructor() {
		this.detector = null;
		this.camera = null;
		this.funFactGenerator = null;
		this.ui = new UIHandler();
		this.isRunning = false;
		this.currentLoopId = null;
		this.config = APP_CONFIG;
		this.currentFunFact = '';

		// TODO [Advanced] Tambahkan properti untuk tone yang dipilih

		this.ui.disableButton();

		this.bindEvents();
		this.init();
		// TODO [Basic] Panggil registerServiceWorker()
	}

	// TODO [Basic] Bind toggle camera event dengan nama onToggleCamera
	// TODO [Basic] Bind camera change event dengan nama onCameraChange
	// TODO [Skilled] Bind FPS change event dengan nama onFPSChange
	// TODO [Skilled] Bind copy fun fact event dengan nama onCopy
	// TODO [Advanced] Bind tone change event dengan nama onToneChange
	bindEvents() {
		this.ui.bindEvents({});
	}
	
	// TODO [Skilled] Perbarui status header UI menjadi 'Memuat model...' saat memulai inisialisasi
	// TODO [Basic] Lengkapi inisialisasi kemampuan aplikasi
	// TODO [Skilled] Perbarui status header UI menjadi 'Siap'
	async init() {
		try { } catch (error) {
			logError('Gagal menginisialisasi aplikasi', error);
			// TODO [Skilled] Perbarui status header UI menjadi 'Error' jika inisialisasi gagal
			this.ui.updateHeaderStatus('Error', false);
			this.ui.showError(`Gagal menginisialisasi: ${error.message}`);
			this.ui.disableButton();
		}
	}


	// TODO [Basic] Buatlah berkas sw.js di root project dan konfigurasikan precaching di dalamnya menggunakan Workbox
	// TODO [Basic] Registrasikan Service Worker
	// TODO [Skilled] Buatlah metode untuk menyalin fun fact ke clipboard

	toggleCamera() {
		if (!this.detector || !this.detector.isLoaded()) {
			this.ui.showError('Model AI belum siap. Harap tunggu.');
			return;
		}

		if (!this.isRunning) {
			this.startCamera();
		} else {
			this.stopCamera();
		}
	}

	async startCamera() {
		try {
			this.ui.updateCameraUI(true);

			if (this.camera) {
				await this.camera.startCamera();
				this.startDetection();
			} else {
				throw new Error('Modul kamera tidak terinisialisasi');
			}

		} catch (error) {
			logError('Gagal memulai kamera', error);
			this.ui.updateCameraUI(false);
			this.ui.showError(error.message);
		}
	}

	stopCamera() {
		this.isRunning = false;
		this.stopDetection();

		if (this.camera) {
			this.camera.stopCamera();
		}

		this.ui.updateCameraUI(false);
	}

	startDetection() {
		if (this.isRunning) return;
		this.isRunning = true;

		this.currentLoopId = Date.now() + Math.random();
		this.detectLoop(this.currentLoopId);
	}

	stopDetection() {
		this.isRunning = false;
		this.currentLoopId = null;
	}

	// TODO [Basic] Implementasikan metode deteksi utama
	async detectLoop(loopId) {}

	// TODO [Basic] Implementasikan metode untuk menghasilkan dan menampilkan fun fact
	async generateAndShowResults(detectionResult) {
		try { } catch (error) {
			logError('Gagal menampilkan hasil', error);
			this.ui.updateFunFactState('error');
		}
	}
}

document.addEventListener('DOMContentLoaded', () => {
	const app = new RootFactsApp();

	if (typeof lucide !== 'undefined') {
		lucide.createIcons();
	}
});

export default RootFactsApp;
